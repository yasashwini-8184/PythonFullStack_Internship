from django.db import models
from django.contrib.auth.models import User

class FarmerProfile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    phone = models.CharField(max_length=15)
    village = models.CharField(max_length=100)
    district = models.CharField(max_length=100)
    state = models.CharField(max_length=100)
    land_area = models.DecimalField(max_digits=6, decimal_places=2)

    def __str__(self):
        return self.user.username
class FarmerRecord(models.Model):

    farmer_name = models.CharField(max_length=100)
    crop_name = models.CharField(max_length=100)
    land_area = models.DecimalField(max_digits=6, decimal_places=2)
    village = models.CharField(max_length=100)
    season = models.CharField(max_length=50)

    def __str__(self):
        return self.farmer_name