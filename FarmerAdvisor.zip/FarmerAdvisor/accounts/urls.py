from django.urls import path
from . import views

urlpatterns = [

    path('', views.home, name='home'),

    path('register/', views.register, name='register'),

    path('login/', views.login_user, name='login'),
    path('dashboard/', views.dashboard, name='dashboard'),
    path('crop/', views.crop_recommendation, name='crop'),
    path('irrigation/', views.irrigation, name='irrigation'),
    path('records/', views.farmer_records, name='records'),
    path('profit/', views.profit_estimator, name='profit'),
    path('logout/', views.logout_user, name='logout'),
    path('about/', views.about, name='about'),
]