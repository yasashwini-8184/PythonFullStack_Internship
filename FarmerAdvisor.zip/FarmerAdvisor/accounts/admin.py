from django.contrib import admin
from .models import FarmerProfile, FarmerRecord

admin.site.register(FarmerProfile)
admin.site.register(FarmerRecord)