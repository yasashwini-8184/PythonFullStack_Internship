from django import forms
from django.contrib.auth.models import User
from .models import FarmerProfile
from .models import FarmerRecord


class UserRegistrationForm(forms.ModelForm):
    password = forms.CharField(widget=forms.PasswordInput)

    class Meta:
        model = User
        fields = ['username', 'email', 'password']


class FarmerProfileForm(forms.ModelForm):

    class Meta:
        model = FarmerProfile
        fields = ['phone', 'village', 'district', 'state', 'land_area']
class FarmerRecordForm(forms.ModelForm):

    class Meta:
        model = FarmerRecord

        fields = [
            'farmer_name',
            'crop_name',
            'land_area',
            'village',
            'season'
        ]