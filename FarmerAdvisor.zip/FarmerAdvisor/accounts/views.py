from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login, logout
from django.contrib import messages
from django.contrib.auth.models import User
from .forms import UserRegistrationForm, FarmerProfileForm
from .models import FarmerProfile
from .forms import FarmerRecordForm
from .models import FarmerRecord

def home(request):
    return render(request, "home.html")
def register(request):

    if request.method == "POST":

        user_form = UserRegistrationForm(request.POST)
        profile_form = FarmerProfileForm(request.POST)

        if user_form.is_valid() and profile_form.is_valid():

            # Save user
            user = user_form.save(commit=False)
            user.set_password(user_form.cleaned_data['password'])
            user.save()

            # Save profile
            profile = profile_form.save(commit=False)
            profile.user = user
            profile.save()

            messages.success(request, "Registration Successful! Please Login.")

            return redirect('login')

        else:
            print(user_form.errors)
            print(profile_form.errors)

    else:

        user_form = UserRegistrationForm()
        profile_form = FarmerProfileForm()

    context = {
        'user_form': user_form,
        'profile_form': profile_form
    }

    return render(request, 'register.html', context)
def login_user(request):

    if request.method == "POST":

        username = request.POST['username']
        password = request.POST['password']

        user = authenticate(request,
                            username=username,
                            password=password)

        if user is not None:

            login(request, user)

            return redirect('dashboard')

        else:

            messages.error(request, "Invalid Username or Password")

    return render(request, 'login.html')
from django.contrib.auth.decorators import login_required

@login_required
def dashboard(request):
    return render(request, "dashboard.html")
@login_required
def crop_recommendation(request):
    return render(request, "crop.html")
@login_required
def crop_recommendation(request):

    crop = None

    if request.method == "POST":

        soil = request.POST['soil']
        season = request.POST['season']

        if soil == "Black Soil" and season == "Kharif":
            crop = "Cotton"

        elif soil == "Red Soil" and season == "Rabi":
            crop = "Groundnut"

        elif soil == "Clay Soil":
            crop = "Rice"

        elif soil == "Sandy Soil":
            crop = "Millets"

        else:
            crop = "Maize"

    return render(request, "crop.html", {"crop": crop})
@login_required
def irrigation(request):

    water = None

    if request.method == "POST":

        crop = request.POST['crop']
        area = float(request.POST['area'])

        if crop == "Rice":
            water = area * 1200

        elif crop == "Cotton":
            water = area * 700

        elif crop == "Groundnut":
            water = area * 500

        elif crop == "Maize":
            water = area * 600

        else:
            water = area * 550

    return render(request, "irrigation.html", {"water": water})

@login_required
def farmer_records(request):

    if request.method == "POST":

        form = FarmerRecordForm(request.POST)

        if form.is_valid():
            form.save()
            messages.success(request, "Farmer Record Added Successfully!")
            return redirect('records')

    else:
        form = FarmerRecordForm()

    records = FarmerRecord.objects.all()

    context = {
        "form": form,
        "records": records
    }

    return render(request, "records.html", context)
@login_required
def profit_estimator(request):

    profit = None

    if request.method == "POST":

        crop = request.POST['crop']
        area = float(request.POST['area'])

        if crop == "Rice":
            profit = area * 40000

        elif crop == "Cotton":
            profit = area * 60000

        elif crop == "Groundnut":
            profit = area * 50000

        elif crop == "Maize":
            profit = area * 35000

        else:
            profit = 0

    return render(request, "profit.html", {"profit": profit})
from django.contrib.auth import logout

@login_required
def logout_user(request):
    logout(request)
    messages.success(request, "Logged out successfully.")
    return redirect('home')
def about(request):
    return render(request, "about.html")