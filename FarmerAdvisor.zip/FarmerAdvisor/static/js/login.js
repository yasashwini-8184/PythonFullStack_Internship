document.addEventListener("DOMContentLoaded", function(){

    const loginForm = document.getElementById("loginForm");

    loginForm.addEventListener("submit", function(e){

        const username = document.getElementById("username").value.trim();

        const password = document.getElementById("password").value.trim();

        if(username==="" || password===""){

            alert("Please enter Username and Password");

            e.preventDefault();

        }

    });

});

/* Show Password */

function showPassword(){

    let password=document.getElementById("password");

    if(password.type==="password"){

        password.type="text";

    }

    else{

        password.type="password";

    }

}