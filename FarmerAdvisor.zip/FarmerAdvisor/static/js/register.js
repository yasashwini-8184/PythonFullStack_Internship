document.addEventListener("DOMContentLoaded", function () {

    const form = document.querySelector("form");

    form.addEventListener("submit", function (event) {

        const username = document.getElementById("id_username").value.trim();
        const email = document.getElementById("id_email").value.trim();
        const password = document.getElementById("id_password").value.trim();
        const phone = document.getElementById("id_phone").value.trim();
        const village = document.getElementById("id_village").value.trim();
        const district = document.getElementById("id_district").value.trim();
        const state = document.getElementById("id_state").value.trim();
        const landArea = document.getElementById("id_land_area").value.trim();

        if (
            username === "" ||
            email === "" ||
            password === "" ||
            phone === "" ||
            village === "" ||
            district === "" ||
            state === "" ||
            landArea === ""
        ) {
            alert("Please fill all fields.");
            event.preventDefault();
            return;
        }

        if (password.length < 8) {
            alert("Password must be at least 8 characters long.");
            event.preventDefault();
            return;
        }

        if (!/^[0-9]{10}$/.test(phone)) {
            alert("Enter a valid 10-digit phone number.");
            event.preventDefault();
            return;
        }

        if (parseFloat(landArea) <= 0) {
            alert("Land area must be greater than zero.");
            event.preventDefault();
            return;
        }

    });

});