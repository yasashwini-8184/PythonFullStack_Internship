document.addEventListener("DOMContentLoaded", function () {

    const button = document.getElementById("startBtn");

    button.addEventListener("click", function(){

        alert("Welcome to Smart Farmer Advisor!");

    });

});