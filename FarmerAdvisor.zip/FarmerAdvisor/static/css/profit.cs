.profit-box{

width:500px;

margin:40px auto;

padding:30px;

background:white;

border-radius:15px;

box-shadow:0 8px 20px rgba(0,0,0,.3);

}

.profit-box h2{

text-align:center;

color:#2E7D32;

margin-bottom:20px;

}

label{

display:block;

margin-top:15px;

font-weight:bold;

}

input,select{

width:100%;

padding:10px;

margin-top:5px;

}

button{

margin-top:20px;

width:100%;

padding:12px;

background:#2E7D32;

color:white;

border:none;

border-radius:5px;

cursor:pointer;

}

.result{

margin-top:25px;

text-align:center;

background:#E8F5E9;

padding:20px;

border-radius:10px;

}